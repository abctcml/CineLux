# CineLux — mã nguồn Flutter cho Android

Ứng dụng mẫu có giao diện điện ảnh tối, kết hợp phong cách Apple TV/Netflix:
- Trang chủ với banner lớn và danh sách phim.
- Tải danh sách phim mới từ API NguonC.
- Tìm kiếm theo tên trong danh sách đã tải.
- Trang thông tin phim và danh sách tập (tùy cấu trúc API thực tế).
- Thư viện phim yêu thích được lưu trên thiết bị.
- Trình phát video cho URL trực tiếp `.m3u8` hoặc `.mp4` tương thích.

## Lưu ý quan trọng
Đây là **mã nguồn dự án khởi đầu**, chưa phải APK đã biên dịch. Môi trường tạo file này không có Flutter/Android SDK để biên dịch và kiểm thử APK. API bên thứ ba có thể thay đổi hoặc không cho phép truy cập từ ứng dụng. Hãy xác nhận điều khoản API và quyền phát/phân phối nội dung; chỉ phát video mà bạn có quyền sử dụng. Mã mẫu không vượt DRM, đăng nhập, paywall hoặc biện pháp bảo vệ nội dung.

## 1. Cài công cụ
- Flutter SDK: https://docs.flutter.dev/get-started/install
- Android Studio và Android SDK: https://developer.android.com/studio
- VS Code (tùy chọn): https://code.visualstudio.com/

## 2. Tạo khung Flutter chuẩn
Mở terminal/Command Prompt tại thư mục bạn muốn lưu dự án, chạy:

```bash
flutter create cinelux
```

Giải nén file ZIP này. Sao chép thư mục `lib` và file `pubspec.yaml` từ gói CineLux vào thư mục `cinelux` vừa tạo, ghi đè khi được hỏi. Nếu muốn đổi tên hiển thị ứng dụng, cập nhật `android/app/src/main/AndroidManifest.xml` thành nhãn `CineLux` và giữ các cấu hình mặc định khác do Flutter tạo.

Sau đó mở terminal tại thư mục dự án `cinelux` và chạy:

```bash
flutter doctor
flutter pub get
flutter run
```

## 3. Tạo APK
Trong thư mục dự án, chạy:

```bash
flutter build apk --release
```

APK sẽ được tạo tại:
`build/app/outputs/flutter-apk/app-release.apk`

Tạo APK riêng theo kiến trúc CPU để giảm dung lượng:

```bash
flutter build apk --split-per-abi
```

## API đang được tham chiếu
- Danh sách phim mới: `https://phim.nguonc.com/api/films/phim-moi-cap-nhat?page=1`
- Chi tiết phim: `https://phim.nguonc.com/api/film/{slug}`

Đây là API của bên thứ ba, không được bảo đảm ổn định. Nếu JSON thay đổi, cập nhật lớp `NguonCService` và phần đọc dữ liệu trong `lib/main.dart`. Một số tập có thể chỉ trả về liên kết nhúng thay vì URL video trực tiếp; trình phát mẫu chỉ xử lý URL trực tiếp `.m3u8`/`.mp4`.

## Trước khi phát hành
Kiểm thử trên thiết bị thật, xử lý đầy đủ lỗi mạng và cấu trúc API, bổ sung chính sách quyền riêng tư, kiểm tra quyền sử dụng nội dung, cấu hình ký bản phát hành và thay biểu tượng ứng dụng.
