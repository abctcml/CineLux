import 'dart:convert';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';

void main() => runApp(const CineLuxApp());

const Color bg = Color(0xFF08090D);
const Color panel = Color(0xFF151720);
const Color accent = Color(0xFFE7B96A);

class CineLuxApp extends StatelessWidget {
  const CineLuxApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CineLux',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: const ColorScheme.dark(
          primary: accent,
          surface: panel,
        ),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      home: const HomeScreen(),
    );
  }
}

class Movie {
  final String name, slug, poster, thumb, description, year, quality, episode;
  final String language;
  final int totalEpisodes;

  const Movie({
    required this.name,
    required this.slug,
    required this.poster,
    required this.thumb,
    required this.description,
    required this.year,
    required this.quality,
    required this.episode,
    required this.language,
    required this.totalEpisodes,
  });

  factory Movie.fromJson(Map<String, dynamic> j) {
    String str(dynamic v) => v == null ? '' : v.toString();
    return Movie(
      name: str(j['name']).isNotEmpty ? str(j['name']) : 'Phim chưa có tên',
      slug: str(j['slug']),
      poster: _imageUrl(str(j['poster_url'])),
      thumb: _imageUrl(str(j['thumb_url'])),
      description: str(j['description']),
      year: str(j['year']),
      quality: str(j['quality']),
      episode: str(j['current_episode']),
      language: str(j['language']),
      totalEpisodes: int.tryParse(str(j['total_episodes'])) ?? 0,
    );
  }

  static String _imageUrl(String value) {
    if (value.isEmpty) return '';
    if (value.startsWith('http://') || value.startsWith('https://')) return value;
    return 'https://phim.nguonc.com$imagePath(value)';
  }

  static String imagePath(String value) => value.startsWith('/') ? value : '/$value';
}

class NguonCService {
  static const baseUrl = 'https://phim.nguonc.com/api';

  Future<List<Movie>> latest({int page = 1}) async {
    final uri = Uri.parse('$baseUrl/films/phim-moi-cap-nhat?page=$page');
    final response = await http.get(uri).timeout(const Duration(seconds: 15));
    if (response.statusCode != 200) {
      throw Exception('Máy chủ trả về mã ${response.statusCode}');
    }
    final decoded = jsonDecode(utf8.decode(response.bodyBytes));
    final items = decoded['items'];
    if (items is! List) return [];
    return items
        .whereType<Map<String, dynamic>>()
        .map(Movie.fromJson)
        .toList();
  }

  Future<Map<String, dynamic>> detail(String slug) async {
    final response = await http
        .get(Uri.parse('$baseUrl/film/${Uri.encodeComponent(slug)}'))
        .timeout(const Duration(seconds: 15));
    if (response.statusCode != 200) {
      throw Exception('Không tải được thông tin phim (${response.statusCode})');
    }
    final decoded = jsonDecode(utf8.decode(response.bodyBytes));
    final data = decoded['movie'] ?? decoded['film'] ?? decoded['data'] ?? decoded;
    if (data is Map<String, dynamic>) return data;
    throw Exception('Dữ liệu chi tiết phim không đúng định dạng.');
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final service = NguonCService();
  final searchController = TextEditingController();
  List<Movie> movies = [];
  Set<String> favorites = {};
  bool loading = true;
  String? error;
  int tab = 0;
  String query = '';

  @override
  void initState() {
    super.initState();
    _loadFavorites();
    _loadMovies();
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  Future<void> _loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) setState(() => favorites = (prefs.getStringList('favorites') ?? []).toSet());
  }

  Future<void> _toggleFavorite(Movie movie) async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      if (favorites.contains(movie.slug)) {
        favorites.remove(movie.slug);
      } else {
        favorites.add(movie.slug);
      }
    });
    await prefs.setStringList('favorites', favorites.toList());
  }

  Future<void> _loadMovies() async {
    setState(() { loading = true; error = null; });
    try {
      final result = await service.latest();
      if (mounted) setState(() { movies = result; loading = false; });
    } catch (e) {
      if (mounted) setState(() { error = e.toString(); loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    final filtered = movies.where((m) {
      final matchesQuery = m.name.toLowerCase().contains(query.toLowerCase());
      return matchesQuery && (tab != 2 || favorites.contains(m.slug));
    }).toList();

    return Scaffold(
      body: SafeArea(
        child: RefreshIndicator(
          color: accent,
          backgroundColor: panel,
          onRefresh: _loadMovies,
          child: CustomScrollView(
            slivers: [
              SliverToBoxAdapter(child: _header()),
              if (tab == 1)
                SliverToBoxAdapter(child: _searchBox())
              else if (tab == 0 && movies.isNotEmpty && query.isEmpty)
                SliverToBoxAdapter(child: _hero(movies.first)),
              if (tab == 0 && query.isEmpty)
                const SliverToBoxAdapter(child: SectionTitle(title: 'Mới cập nhật', subtitle: 'Phim mới dành cho bạn')),
              if (tab == 1)
                const SliverToBoxAdapter(child: SectionTitle(title: 'Khám phá', subtitle: 'Tìm bộ phim bạn muốn xem')),
              if (tab == 2)
                const SliverToBoxAdapter(child: SectionTitle(title: 'Thư viện của bạn', subtitle: 'Phim đã lưu yêu thích')),
              if (loading)
                const SliverFillRemaining(hasScrollBody: false, child: Center(child: CircularProgressIndicator(color: accent)))
              else if (error != null)
                SliverFillRemaining(
                  hasScrollBody: false,
                  child: Center(child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.cloud_off_rounded, size: 42, color: Colors.white54),
                      const SizedBox(height: 12),
                      Text('Chưa tải được dữ liệu phim', style: Theme.of(context).textTheme.titleMedium),
                      const SizedBox(height: 8),
                      Text(error!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white54)),
                      const SizedBox(height: 16),
                      FilledButton(onPressed: _loadMovies, child: const Text('Thử lại')),
                    ]),
                  )),
                )
              else if (filtered.isEmpty)
                const SliverFillRemaining(hasScrollBody: false, child: Center(child: Text('Không tìm thấy phim phù hợp.')))
              else
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                  sliver: SliverGrid(
                    delegate: SliverChildBuilderDelegate(
                      (context, index) => MovieCard(
                        movie: filtered[index],
                        isFavorite: favorites.contains(filtered[index].slug),
                        onFavorite: () => _toggleFavorite(filtered[index]),
                      ),
                      childCount: filtered.length,
                    ),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      crossAxisSpacing: 10,
                      mainAxisSpacing: 16,
                      childAspectRatio: .53,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF101117),
        indicatorColor: accent.withOpacity(.15),
        selectedIndex: tab,
        onDestinationSelected: (i) {
          setState(() {
            tab = i;
            query = '';
            searchController.clear();
          });
        },
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'Trang chủ'),
          NavigationDestination(icon: Icon(Icons.explore_outlined), selectedIcon: Icon(Icons.explore), label: 'Khám phá'),
          NavigationDestination(icon: Icon(Icons.bookmark_border), selectedIcon: Icon(Icons.bookmark), label: 'Thư viện'),
        ],
      ),
    );
  }

  Widget _header() => Padding(
    padding: const EdgeInsets.fromLTRB(18, 14, 18, 8),
    child: Row(children: [
      Container(
        width: 42, height: 42,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          gradient: const LinearGradient(colors: [Color(0xFFF4D69A), Color(0xFF9D6A2C)]),
        ),
        child: const Icon(Icons.play_arrow_rounded, color: Colors.black, size: 30),
      ),
      const SizedBox(width: 10),
      const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('CINELUX', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 2.2)),
        Text('Điện ảnh trong tầm tay', style: TextStyle(fontSize: 11, color: Colors.white54)),
      ])),
      IconButton(onPressed: _loadMovies, icon: const Icon(Icons.refresh_rounded), tooltip: 'Tải lại'),
    ]),
  );

  Widget _searchBox() => Padding(
    padding: const EdgeInsets.fromLTRB(16, 4, 16, 14),
    child: TextField(
      controller: searchController,
      onChanged: (v) => setState(() => query = v),
      decoration: InputDecoration(
        hintText: 'Tìm tên phim...',
        prefixIcon: const Icon(Icons.search),
        filled: true,
        fillColor: panel,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
      ),
    ),
  );

  Widget _hero(Movie movie) => Padding(
    padding: const EdgeInsets.fromLTRB(16, 10, 16, 22),
    child: GestureDetector(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DetailScreen(movie: movie, onFavorite: () => _toggleFavorite(movie), isFavorite: favorites.contains(movie.slug)))),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: SizedBox(
          height: 360,
          child: Stack(fit: StackFit.expand, children: [
            _poster(movie.thumb.isNotEmpty ? movie.thumb : movie.poster, fit: BoxFit.cover),
            const DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.black12, Colors.transparent, Color(0xF5000000)], stops: [0, .35, 1]))),
            Positioned(top: 16, left: 16, child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(color: accent, borderRadius: BorderRadius.circular(30)),
              child: const Text('ĐỀ XUẤT', style: TextStyle(color: Colors.black, fontWeight: FontWeight.w900, fontSize: 10, letterSpacing: 1)),
            )),
            Positioned(left: 18, right: 18, bottom: 20, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(movie.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900, height: 1.1)),
              const SizedBox(height: 8),
              Text([movie.quality, movie.language, movie.episode].where((e) => e.isNotEmpty).join(' • '), style: const TextStyle(color: Colors.white70, fontSize: 12)),
              const SizedBox(height: 14),
              Row(children: [
                FilledButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DetailScreen(movie: movie, onFavorite: () => _toggleFavorite(movie), isFavorite: favorites.contains(movie.slug)))), icon: const Icon(Icons.play_arrow_rounded), label: const Text('Xem chi tiết')),
                const SizedBox(width: 10),
                IconButton.filledTonal(onPressed: () => _toggleFavorite(movie), icon: Icon(favorites.contains(movie.slug) ? Icons.bookmark : Icons.bookmark_add_outlined)),
              ]),
            ])),
          ]),
        ),
      ),
    ),
  );

  Widget _poster(String url, {BoxFit fit = BoxFit.cover}) {
    if (url.isEmpty) return Container(color: panel, child: const Icon(Icons.movie_outlined, size: 36, color: Colors.white30));
    return CachedNetworkImage(
      imageUrl: url,
      fit: fit,
      placeholder: (_, __) => Container(color: panel, child: const Center(child: Icon(Icons.movie_outlined, color: Colors.white24))),
      errorWidget: (_, __, ___) => Container(color: panel, child: const Center(child: Icon(Icons.broken_image_outlined, color: Colors.white24))),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String title, subtitle;
  const SectionTitle({super.key, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(18, 4, 18, 14),
    child: Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800)),
        const SizedBox(height: 3),
        Text(subtitle, style: const TextStyle(color: Colors.white54, fontSize: 12)),
      ])),
    ]),
  );
}

class MovieCard extends StatelessWidget {
  final Movie movie;
  final bool isFavorite;
  final VoidCallback onFavorite;
  const MovieCard({super.key, required this.movie, required this.isFavorite, required this.onFavorite});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DetailScreen(movie: movie, onFavorite: onFavorite, isFavorite: isFavorite))),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Expanded(child: ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: Stack(fit: StackFit.expand, children: [
          CachedNetworkImage(
            imageUrl: movie.poster.isNotEmpty ? movie.poster : movie.thumb,
            fit: BoxFit.cover,
            placeholder: (_, __) => Container(color: panel),
            errorWidget: (_, __, ___) => Container(color: panel, child: const Icon(Icons.movie_outlined, color: Colors.white24)),
          ),
          Positioned(top: 5, right: 5, child: GestureDetector(
            onTap: onFavorite,
            child: Container(
              padding: const EdgeInsets.all(5),
              decoration: BoxDecoration(color: Colors.black.withOpacity(.7), shape: BoxShape.circle),
              child: Icon(isFavorite ? Icons.bookmark : Icons.bookmark_border, size: 16, color: isFavorite ? accent : Colors.white),
            ),
          )),
        ]),
      )),
      const SizedBox(height: 7),
      Text(movie.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, height: 1.2)),
      const SizedBox(height: 3),
      Text([movie.quality, movie.episode].where((e) => e.isNotEmpty).join(' • '), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10, color: Colors.white54)),
    ]),
  );
}

class DetailScreen extends StatefulWidget {
  final Movie movie;
  final VoidCallback onFavorite;
  final bool isFavorite;
  const DetailScreen({super.key, required this.movie, required this.onFavorite, required this.isFavorite});

  @override
  State<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> {
  Map<String, dynamic>? detail;
  bool loading = true;
  String? error;

  @override
  void initState() {
    super.initState();
    _loadDetail();
  }

  Future<void> _loadDetail() async {
    try {
      final result = await NguonCService().detail(widget.movie.slug);
      if (mounted) setState(() { detail = result; loading = false; });
    } catch (e) {
      if (mounted) setState(() { error = e.toString(); loading = false; });
    }
  }

  List<Map<String, dynamic>> _episodes() {
    if (detail == null) return [];
    final raw = detail!['episodes'];
    if (raw is! List) return [];
    final result = <Map<String, dynamic>>[];
    for (final server in raw) {
      if (server is Map && server['items'] is List) {
        for (final ep in server['items']) {
          if (ep is Map) {
            result.add({
              'name': ep['name']?.toString() ?? ep['slug']?.toString() ?? 'Tập phim',
              'url': ep['m3u8']?.toString() ?? ep['link_m3u8']?.toString() ?? ep['embed']?.toString() ?? ep['link_embed']?.toString() ?? '',
            });
          }
        }
      }
    }
    return result;
  }

  @override
  Widget build(BuildContext context) {
    final m = widget.movie;
    final synopsis = (detail?['description'] ?? detail?['content'] ?? m.description).toString();
    return Scaffold(
      body: CustomScrollView(slivers: [
        SliverAppBar(
          expandedHeight: 370,
          pinned: true,
          backgroundColor: bg,
          flexibleSpace: FlexibleSpaceBar(
            title: Text(m.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
            background: Stack(fit: StackFit.expand, children: [
              CachedNetworkImage(imageUrl: m.thumb.isNotEmpty ? m.thumb : m.poster, fit: BoxFit.cover,
                errorWidget: (_, __, ___) => Container(color: panel)),
              const DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.black38, Colors.transparent, bg], stops: [0, .35, 1]))),
            ]),
          ),
          actions: [IconButton(onPressed: widget.onFavorite, icon: Icon(widget.isFavorite ? Icons.bookmark : Icons.bookmark_add_outlined, color: accent))],
        ),
        SliverToBoxAdapter(child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 30),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Wrap(spacing: 8, runSpacing: 8, children: [
              if (m.quality.isNotEmpty) _chip(m.quality),
              if (m.language.isNotEmpty) _chip(m.language),
              if (m.totalEpisodes > 0) _chip('${m.totalEpisodes} tập'),
              if (m.episode.isNotEmpty) _chip(m.episode),
            ]),
            const SizedBox(height: 18),
            const Text('Nội dung phim', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Text(synopsis.isEmpty ? 'Chưa có mô tả cho phim này.' : synopsis, style: const TextStyle(color: Colors.white70, height: 1.55)),
            const SizedBox(height: 24),
            const Text('Danh sách tập', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            if (loading) const Center(child: Padding(padding: EdgeInsets.all(20), child: CircularProgressIndicator(color: accent)))
            else if (error != null) Text('Không tải được danh sách tập: $error', style: const TextStyle(color: Colors.white54))
            else if (_episodes().isEmpty) const Text('Nguồn dữ liệu chưa trả về danh sách tập hoặc định dạng đã thay đổi.', style: TextStyle(color: Colors.white54))
            else Wrap(spacing: 8, runSpacing: 8, children: _episodes().asMap().entries.map((entry) {
              final ep = entry.value;
              return OutlinedButton(
                onPressed: (ep['url'] as String).isEmpty ? null : () {
                  final url = ep['url'] as String;
                  if (url.contains('.m3u8') || url.endsWith('.mp4')) {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => PlayerScreen(title: '${m.name} - ${ep['name']}', url: url)));
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Liên kết này là embed. Hãy tích hợp WebView/player phù hợp và chỉ phát nội dung bạn có quyền sử dụng.')));
                  }
                },
                child: Text(ep['name'] as String),
              );
            }).toList()),
            const SizedBox(height: 18),
            const Text('Lưu ý: chỉ phát hoặc phân phối video khi bạn có quyền sử dụng nội dung đó.', style: TextStyle(fontSize: 11, color: Colors.white38)),
          ]),
        )),
      ]),
    );
  }

  Widget _chip(String text) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(30), border: Border.all(color: Colors.white12)),
    child: Text(text, style: const TextStyle(fontSize: 11, color: accent, fontWeight: FontWeight.w600)),
  );
}

class PlayerScreen extends StatefulWidget {
  final String title, url;
  const PlayerScreen({super.key, required this.title, required this.url});
  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  VideoPlayerController? controller;
  String? error;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      final c = VideoPlayerController.networkUrl(Uri.parse(widget.url));
      controller = c;
      await c.initialize();
      await c.play();
      if (mounted) setState(() {});
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    }
  }

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = controller;
    return Scaffold(
      appBar: AppBar(title: Text(widget.title, maxLines: 1, overflow: TextOverflow.ellipsis)),
      backgroundColor: Colors.black,
      body: Center(
        child: error != null
          ? Padding(padding: const EdgeInsets.all(24), child: Text('Không phát được video. Có thể liên kết không trực tiếp, hết hạn hoặc không tương thích.\n\n$error', textAlign: TextAlign.center))
          : c == null || !c.value.isInitialized
            ? const CircularProgressIndicator(color: accent)
            : AspectRatio(
                aspectRatio: c.value.aspectRatio,
                child: Stack(alignment: Alignment.bottomCenter, children: [
                  VideoPlayer(c),
                  VideoProgressIndicator(c, allowScrubbing: true, colors: const VideoProgressColors(playedColor: accent, bufferedColor: Colors.white38, backgroundColor: Colors.white12)),
                  Positioned(
                    bottom: 20, left: 0, right: 0,
                    child: IconButton(
                      iconSize: 54,
                      color: Colors.white,
                      onPressed: () => setState(() => c.value.isPlaying ? c.pause() : c.play()),
                      icon: Icon(c.value.isPlaying ? Icons.pause_circle_filled : Icons.play_circle_fill),
                    ),
                  ),
                ]),
              ),
      ),
    );
  }
}
